// Track which tabs currently have our panel "open" (best-effort in MV3).
const openTabs = new Set();

// Listen for sidepanel lifecycle pings
chrome.runtime.onMessage.addListener((msg, sender) => {
  const tabId = sender?.tab?.id;
  if (!tabId) return;

  if (msg?.type === "PANEL_OPEN") openTabs.add(tabId);
  if (msg?.type === "PANEL_CLOSED") openTabs.delete(tabId);
});

// Also clean up when a tab is closed
chrome.tabs.onRemoved.addListener((tabId) => {
  openTabs.delete(tabId);
});

chrome.action.onClicked.addListener((tab) => {
  const tabId = tab?.id;
  if (!tabId) return;

  // If we believe it's open, "close" by disabling it for this tab
  if (openTabs.has(tabId)) {
    chrome.sidePanel.setOptions({ tabId, enabled: false })
      .catch((e) => console.error("setOptions disable failed:", e));
    openTabs.delete(tabId);
    return;
  }

  // IMPORTANT: Do not await anything before open()
  chrome.sidePanel.setOptions({ tabId, path: "sidepanel.html", enabled: true })
    .catch((e) => console.error("setOptions enable failed:", e));

  if (chrome.sidePanel?.open) {
    chrome.sidePanel.open({ tabId })
      .then(() => openTabs.add(tabId))
      .catch((e) => console.error("sidePanel.open failed:", e));
  } else {
    console.error("chrome.sidePanel.open not available in this browser build.");
  }
});
