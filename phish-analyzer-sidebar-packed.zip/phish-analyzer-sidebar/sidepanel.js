const DEFAULT_API_BASE = "https://demo.phishing-analyzer.com";

const els = {
  apiUrl: document.getElementById("apiUrl"),
  saveApiBtn: document.getElementById("saveApiBtn"),
  headers: document.getElementById("headers"),
  charCount: document.getElementById("charCount"),
  analyzeBtn: document.getElementById("analyzeBtn"),
  clearBtn: document.getElementById("clearBtn"),
  out: document.getElementById("out"),
  status: document.getElementById("status"),
  spin: document.getElementById("spin"),
  termTitle: document.getElementById("termTitle"),
  copyBtn: document.getElementById("copyBtn"),
  apiBadge: document.getElementById("apiBadge"),
};

chrome.runtime.sendMessage({ type: "PANEL_OPEN" });

// Best-effort close signal
window.addEventListener("unload", () => {
  chrome.runtime.sendMessage({ type: "PANEL_CLOSED" });
});

function setBusy(busy, label = "working…") {
  els.analyzeBtn.disabled = busy;
  els.clearBtn.disabled = busy;
  els.saveApiBtn.disabled = busy;
  els.headers.readOnly = busy;

  els.spin.style.display = busy ? "inline-block" : "none";
  els.status.textContent = busy ? label : "idle";
  els.termTitle.textContent = busy ? "output://processing" : "output://ready";
}

function normalizeHeaders(s) {
  return (s || "")
    .replace(/\r\n/g, "\n")
    .replace(/\r/g, "\n")
    .trim() + "\n";
}

function headersToTxtFile(headersText) {
  const blob = new Blob([headersText], { type: "text/plain" });
  return new File([blob], "headers.txt", { type: "text/plain" });
}

function prettyFromApiResponse(text) {
  // If response is JSON: {"output":"..."} -> show just output
  try {
    const obj = JSON.parse(text);
    if (obj && typeof obj === "object") {
      if (typeof obj.output === "string") return obj.output.trimEnd();
      return JSON.stringify(obj, null, 2);
    }
  } catch {}
  return text;
}

async function getApiBase() {
  const { apiBase } = await chrome.storage.sync.get({ apiBase: DEFAULT_API_BASE });
  return (apiBase || DEFAULT_API_BASE).replace(/\/+$/, "");
}

async function setApiBase(value) {
  const cleaned = (value || "").trim().replace(/\/+$/, "");
  await chrome.storage.sync.set({ apiBase: cleaned });
  return cleaned;
}

async function init() {
  const apiBase = await getApiBase();
  els.apiUrl.value = apiBase;
  updateCharCount();

  els.saveApiBtn.addEventListener("click", async () => {
    const v = await setApiBase(els.apiUrl.value);
    els.apiUrl.value = v;
    log(`$ saved\n# api base: ${v}\n`);
  });

  els.headers.addEventListener("input", updateCharCount);

  els.clearBtn.addEventListener("click", () => {
    els.headers.value = "";
    updateCharCount();
    log(`$ cleared\n# paste headers above and click Analyze.\n`);
  });

  els.analyzeBtn.addEventListener("click", analyze);

  els.copyBtn.addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText(els.out.textContent);
      els.status.textContent = "copied";
      setTimeout(() => (els.status.textContent = "idle"), 800);
    } catch {
      els.status.textContent = "copy failed";
      setTimeout(() => (els.status.textContent = "idle"), 1200);
    }
  });
}

function updateCharCount() {
  const n = (els.headers.value || "").length;
  els.charCount.textContent = `${n.toLocaleString()} chars`;
}

function log(text) {
  els.out.textContent = text;
}

async function analyze() {
  const raw = els.headers.value || "";
  const normalized = normalizeHeaders(raw);

  if (!normalized.trim()) {
    log(`$ error\n# paste headers first.\n`);
    return;
  }

  setBusy(true, "sending");
  els.apiBadge.textContent = "api: working";

  try {
    const apiBase = await getApiBase();
    const endpoint = `${apiBase}/api/analyze`; // <-- adjust if your API path differs

    log(
`$ analyze
# endpoint: ${endpoint}
# payload: headers.txt (${normalized.length} chars)\n`
    );

    const fd = new FormData();
    fd.append("file", headersToTxtFile(normalized));
    fd.append("create_pdf", "false"); // per your API signature; keep terminal for sidebar MVP

    const res = await fetch(endpoint, { method: "POST", body: fd });

    const ct = (res.headers.get("content-type") || "").toLowerCase();
    const text = ct.includes("application/json") ? await res.text() : await res.text();

    if (!res.ok) {
      throw new Error(`HTTP ${res.status}: ${text}`);
    }

    const cleaned = prettyFromApiResponse(text);
    log(`$ done\n${cleaned}\n`);
    els.apiBadge.textContent = "api: ok";
  } catch (err) {
    log(`$ error\n${String(err?.message || err)}\n`);
    els.apiBadge.textContent = "api: error";
  } finally {
    setBusy(false);
    els.termTitle.textContent = "output://complete";
  }
}

init();
